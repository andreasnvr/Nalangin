angular.module('app.controllers', [])
         
 /*
 * Controller for Login.
 * using Parameter : loginData.username, loginData.password
 * POST to API to Check credential
 */
.controller('loginCtrl', function($scope, $state, $ionicPopup,$location,$ionicHistory) {
    
	console.log("asdads")
    $scope.loginData  = {};
    $scope.login = function() {
        var username = $scope.loginData.username;
        var password = $scope.loginData.password;

        //$('.btn-login').html('Loading....');
        console.log(username)
        console.log(password)

        if( validation($ionicPopup, 'Email', username, 'email') == false
            || validation($ionicPopup, 'Password', password, 'string') == false
        ) {return;};
        /*
        AuthService.login( username, password ).then(function(authenticated) {
            $scope.username = username;
            $('.btn-login').html('SIGN IN');
            $ionicHistory.nextViewOptions({
                disableBack   : true
            });
            $location.path("app/products");

        }, function(err) {
            $('.btn-login').html('SIGN IN');
            var alertPopup = $ionicPopup.alert({
                title   : 'Login Gagal!',
                template: 'Pastikan email dan password benar!'
            });
        });
    	*/
    };
})
